document.addEventListener('DOMContentLoaded', function()
{
  console.log('我被执行了！');
});